interface IPrinter {
    fun Print()
}