class Circle(val radius: Double = 15.0, val pi: Double = 3.14) : IFigure { // Реализация метода для возврата площади
    override fun area(): Double {
        return pi * radius * radius
    }
    override fun perimeter(): Double {
        return 2 * radius * pi
    }

    override fun printInformation() {
        println("Название фигуры: $name")
        println("Радиус: $radius")
        println("Число ПИ: $pi")
        println("Площадь: ${area()}")
        println("Периметр: ${perimeter()}")
    }

    override val name: String
        get() = "Круг"
}

fun main() {
    val circle = Circle()
    circle.printInformation()
}