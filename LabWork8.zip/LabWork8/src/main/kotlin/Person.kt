open class Person(val name: String, val age: Int) {
    open val information: String
        get() = "Name: $name, Age: $age"

    open fun printInformation() {
        println("Информация о человеке: ")
        println("Name: $name")
        println("Age: $age")
    }

    override fun toString(): String {
        return "Person(name='$name', age=$age)"
    }
}