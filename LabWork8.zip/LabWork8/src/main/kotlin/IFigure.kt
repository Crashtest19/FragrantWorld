interface IFigure {
    fun area(): Double
    fun perimeter(): Double
    fun printInformation(): Unit
    val name: String
}