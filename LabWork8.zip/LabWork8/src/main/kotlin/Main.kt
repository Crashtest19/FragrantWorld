fun main() {
    val person = Person("Niki", 19)
    println(person)
    person.printInformation()

    val student = Student("Niki",19,"ISPP-35")
    println(student)
    student.printInformation()

    println("Информация о фигуре")
    val circle = Circle()
    circle.printInformation()

}