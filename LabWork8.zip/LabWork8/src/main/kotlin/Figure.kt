abstract class Figure {
    abstract fun perimeter(): Unit
    abstract fun area(): Unit
    abstract fun information():Unit
    abstract fun nameFigure():String
}