open class Student(name: String, age: Int, val group: String) : Person(name, age) {
    override val information: String
        get() = "${super.information}, Group: $group"


    override fun printInformation() {
        println("Информация о студенте:")
        println("Name: $name")
        println("Age: $age")
        println("Group: $group")
    }

    override fun toString(): String {
        return "${super.toString()}, Group: '$group'"
    }
}