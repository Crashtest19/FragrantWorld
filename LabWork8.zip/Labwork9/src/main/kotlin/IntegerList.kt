class IntegerList {
    val numbers = mutableListOf<Int>()

    fun run() {
        println("Введите количество целых чисел для добавления:")
        val n = readln().toInt()
        repeat(n) {
            println("Введите целое число:")
            numbers.add(readln().toInt())
        }

        println("Индекс элемента, равного 100: ${numbers.indexOf(100)}")
        println("Сумма элементов: ${numbers.sum()}")
        println("Среднее значение: ${numbers.average()}")
        println("Все числа больше нуля: ${numbers.all { it > 0 }}")
        println("Нечетные значения: ${numbers.filter { it % 2 != 0 }}")
    }
}