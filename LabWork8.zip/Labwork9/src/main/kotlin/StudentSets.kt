class StudentSets {
    val students1 = setOf("Студент 1", "Студент 2", "Студент 3")
    val students2 = setOf("Студент 2", "Студент 3", "Студент 4")

    fun run() {
        val allStudents = students1.union(students2)
        val failedBoth = students1.intersect(students2)
        val failedOne = allStudents - failedBoth

        println("Всего студентов на пересдаче: ${allStudents.size}")
        println("Студенты, не сдавшие оба зачета: $failedBoth")
        println("Студенты, не сдавшие только один зачет: $failedOne")

        println("Список всех студентов на пересдаче: $allStudents")
        println("Список студентов, не сдавших оба зачета: $failedBoth")
        println("Список студентов, не сдавших только один зачет: $failedOne")
    }
}