class ProductList {
    private val products = mutableListOf<String>()

    fun run() {
        products.addAll(listOf("Товар 1 - 100", "Товар 2 - 200", "Товар 3 - 300"))

        println("Введите количество товаров для добавления:")
        val n = readln().toInt()
        repeat(n) {
            println("Введите название и цену товара (например, 'Товар 4 - 400'):")
            products.add(readln())
        }

        println("Список товаров:")

        for (index in products.indices) {
            println("${index + 1} - ${products[index]}")
        }
        println("Количество товаров: ${products.size}")
    }
}