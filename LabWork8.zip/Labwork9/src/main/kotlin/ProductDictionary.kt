class ProductDictionary {
    private val products = mutableMapOf<String, Double>()

    fun run() {
        products["Товар 1"] = 100.0
        products["Товар 2"] = 200.0
        products["Товар 3"] = 300.0

        println("Введите количество товаров для добавления:")
        repeat(readln().toInt()) {
            println("Введите название товара:")
            val name = readln()
            println("Введите цену товара:")
            val price = readln().toDouble()
            products[name] = price
        }

        println("Содержимое словаря:\n${products.map { "${it.key} - ${it.value}" }.joinToString("\n")}\nКоличество товаров: ${products.size}")

        println("Введите ключ для поиска:")
        val searchKey = readln()
        println("Значение: ${products[searchKey] ?: "Ключ не найден."}")

        println("Введите значение для подсчета совпадений:")
        val searchValue = readln().toDouble()
        println("Количество совпадений: ${products.values.count { it == searchValue }}")

        println("Введите ключ для удаления:")
        val deleteKey = readln()
        println(if (products.remove(deleteKey) != null) "Элемент удален." else "Ключ не найден.")

        println("Обновленное содержимое словаря:\n${products.map { "${it.key} - ${it.value}" }.joinToString("\n")}")
    }
}