fun main() {
    println("Выберите действие:")
    println("1. Работа со списком товаров")
    println("2. Работа со списком целых чисел")
    println("3. Работа со словарем")
    println("4. Работа с множествами студентов")

    when (readln().toInt()) {
        1 -> ProductList().run()
        2 -> IntegerList().run()
        3 -> ProductDictionary().run()
        4 -> StudentSets().run()
        else -> println("Неверный выбор")
    }
}